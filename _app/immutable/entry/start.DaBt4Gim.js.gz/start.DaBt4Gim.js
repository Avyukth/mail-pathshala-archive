import{l as o,a as r}from"../chunks/B70ZPJXY.js";export{o as load_css,r as start};
